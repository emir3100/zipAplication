﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinMolk
{
    class FileInfoColumn
    {
        public string FileNameFIC { get; set; }
        public string FilePathFIC { get; set; }
        public string FileTypeFIC { get; set; }
        public string FileSizeFIC { get; set; }
    }
}
